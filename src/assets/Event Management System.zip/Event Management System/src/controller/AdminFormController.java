package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.layout.AnchorPane;

import java.io.IOException;
import java.net.URL;

public class AdminFormController {
    public AnchorPane changeAnchorPane;
    public AnchorPane adminContext;

    public void btnRegisterOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/EmployeeRegisterForm.fxml");
        Parent load = FXMLLoader.load(resource);
        changeAnchorPane.getChildren().clear();
        changeAnchorPane.getChildren().add(load);
    }



    public void logOutOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/LoginForm.fxml");
        Parent load = FXMLLoader.load(resource);
        adminContext.getChildren().clear();
        adminContext.getChildren().add(load);
    }


    public void employeeRemoveOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/DeleteForm.fxml");
        Parent load = FXMLLoader.load(resource);
        changeAnchorPane.getChildren().clear();
        changeAnchorPane.getChildren().add(load);
    }

    public void employeeUpdateOnAction(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/EmployeeUpdate.fxml");
        Parent load = FXMLLoader.load(resource);
        changeAnchorPane.getChildren().clear();
        changeAnchorPane.getChildren().add(load);
    }

    public void dalyInComeOnAction(ActionEvent actionEvent) throws IOException {
       /* URL resource = getClass().getResource("../view/EmployeeRegisterForm.fxml");
        Parent load = FXMLLoader.load(resource);
        changeAnchorPane.getChildren().clear();
        changeAnchorPane.getChildren().add(load);*/
    }

    public void monthlyInComeOnAction(ActionEvent actionEvent) {
    }

    public void employeeDetails(ActionEvent actionEvent) throws IOException {
        URL resource = getClass().getResource("../view/EmployeeDetailsForm.fxml");
        Parent load = FXMLLoader.load(resource);
        changeAnchorPane.getChildren().clear();
        changeAnchorPane.getChildren().add(load);
    }
}