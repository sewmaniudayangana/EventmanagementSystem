package controller;

import javafx.event.ActionEvent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class PaymentDetailController {

    public TextField txtTotalPlatePrice;
    public TextField txtOtherExpenses;
    public TextField txtDecoration;
    public TextField txtSubTotal;
    public TextField txtDepositPaid;
    public TextField txtBalance;
    public Label lblAmount;
    public Button buttonPay;

    public void payOnAction(ActionEvent actionEvent) {

    }
}
