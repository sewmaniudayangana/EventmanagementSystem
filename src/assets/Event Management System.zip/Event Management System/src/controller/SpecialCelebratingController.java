package controller;

import javafx.scene.layout.AnchorPane;

public class SpecialCelebratingController {
    public AnchorPane specialCelebrating;
}
