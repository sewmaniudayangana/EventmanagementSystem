package controller;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class DeleteFormController {

    public TextField txtEmployeeId;
    public TextField txtEmployeeName;
    public TextField txtEmployeeAddress;
    public TextField txtEmployeeSalary;
    public TextField txtEmployeeContact;

    public void ConformOnAction(ActionEvent actionEvent) {
    }
}