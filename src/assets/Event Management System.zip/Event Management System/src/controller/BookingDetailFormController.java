package controller;

import javafx.event.ActionEvent;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextField;

public class BookingDetailFormController {
    public TextField txtStartTime;
    public TextField txtBookingId;
    public TextField txtEndTime;
    public DatePicker calendarPreferredEvent;
    public ComboBox cmbPlace;
    public TextField txtCustomerId;
    public TextField txtPlate;

    public void save(ActionEvent actionEvent) {
    }
}
