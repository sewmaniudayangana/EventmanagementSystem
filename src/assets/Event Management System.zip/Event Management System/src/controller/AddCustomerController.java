package controller;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class AddCustomerController {
    public TextField tactfullyName;
    public TextField textAddress;
    public TextField txtNICNumber;
    public TextField txtContactNumber;
    public TextField txtCity;
    public TextField txtCustomer;

    public void RegesterOnAction(ActionEvent actionEvent) {

    }
}
