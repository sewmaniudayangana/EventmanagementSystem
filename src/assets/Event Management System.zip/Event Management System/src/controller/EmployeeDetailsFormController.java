package controller;

import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class EmployeeDetailsFormController {
    public TableView tblEmployeeDetails;
    public TableColumn colId;
    public TableColumn colName;
    public TableColumn colAddress;
    public TableColumn colContact;
    public TableColumn colSalary;
}
