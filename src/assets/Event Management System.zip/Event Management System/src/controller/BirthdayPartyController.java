package controller;

import javafx.scene.layout.AnchorPane;

public class BirthdayPartyController {
    public AnchorPane birthdayParty;
}
