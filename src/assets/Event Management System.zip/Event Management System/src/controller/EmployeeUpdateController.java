package controller;

import javafx.event.ActionEvent;
import javafx.scene.control.TextField;

public class EmployeeUpdateController {

    public TextField txtEmployeeId;
    public TextField txtEmployeeName;
    public TextField txtEmployeeAddress;
    public TextField txtEmployeeContact;
    public TextField txtEmployeeSalary;

    public void saveOnAction(ActionEvent actionEvent) {
    }
}