package controller;

import javafx.scene.layout.AnchorPane;

public class WeddingController {
    public AnchorPane weddingAnchorPane;
}
